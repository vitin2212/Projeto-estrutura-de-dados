public class Node {
    Pixel valor;
    Node proximo;

    public Node(Pixel valor) {
        this.valor = valor;
        this.proximo = null;
    }
}
